📡 Network Topologies using Cisco Packet Tracer

This repository contains implementations of common network topologies created using Cisco Packet Tracer. These projects help understand basic networking concepts, design structures, and communication methods.

🧠 Topologies Included
🔵 Bus Topology

All devices connected to a single backbone cable

Simple and cost-effective

Used for understanding basic data transmission

🔴 Ring Topology

Devices connected in a circular format

Data travels in one direction (or both in dual ring)

Helps understand token passing mechanism

🟢 Star Topology

All devices connected to a central hub/switch

Easy to manage and troubleshoot

Most commonly used in modern networks

🟡 Mesh Topology

Every device connected to every other device

High redundancy and reliability

Used in critical network systems

🌳 Tree Topology

Combination of star and bus topologies

Hierarchical structure

Used in large-scale networks

🛠️ Tools Used

Cisco Packet Tracer

📂 Files Included

.pkt files for each topology

Network configurations and device setups

🎯 Learning Objectives

Understand different network topologies

Learn how devices communicate in each topology

Practice designing networks using Packet Tracer

Gain hands-on networking experience

🚀 How to Use

Download or clone this repository

Open .pkt files using Cisco Packet Tracer

Run simulations and analyze network behavior

👨‍💻 Author

Viraj Jayasinghe

Undergraduate | Computer Science

Interested in Cybersecurity & Networking

⭐ Notes

These topologies were created for educational purposes and practice in networking fundamentals.
